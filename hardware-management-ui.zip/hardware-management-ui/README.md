# Hardware Management UI Demo

A responsive hardware store management dashboard built with HTML, Tailwind CSS (CDN), and vanilla JavaScript. Demo records persist in browser Local Storage.


## Run locally
1. Unzip this project.
2. Open `index.html` in a modern browser, or use VS Code Live Server.
3. Internet access is needed for the Tailwind and Lucide CDN assets.

## Features
- Responsive sidebar and dashboard overview
- Product inventory CRUD with search and low-stock highlighting
- POS cart, quantity controls, customer/payment selection, and transaction confirmation
- Local demo sale processing and stock deduction
- Customer and supplier CRUD
- Purchasing records
- Expense list and summary
- Reports with CSV exports
- eFRIS configuration readiness placeholder (not an active URA integration)
- Local JSON backup and restore
- Demo reset

## Demo limitations
This is a browser-only prototype. Local Storage is not a secure multi-user database. It is not a production POS, does not implement payment provider integrations, does not submit URA eFRIS documents, and does not replace backend transactional controls. Before real deployment, replace local persistence with a secure backend/database, implement server authorization, transaction locking, fiscal integration using official URA documentation, and complete automated tests.
